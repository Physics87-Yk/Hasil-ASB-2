import { initializeApp } from "firebase/app"
import { getFirestore, collection, getDocs, query, where, addDoc, deleteDoc, doc } from "firebase/firestore"
import type { StudentData } from "@/components/student-results"

// Konfigurasi Firebase
// Ganti dengan konfigurasi dari Firebase console Anda
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)
const db = getFirestore(app)

// Fungsi untuk mengambil semua data siswa
export async function getAllStudents() {
  const studentsCol = collection(db, "students")
  const snapshot = await getDocs(studentsCol)
  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  })) as StudentData[]
}

// Fungsi untuk mencari siswa berdasarkan nama
export async function findStudentByName(name: string) {
  const studentsCol = collection(db, "students")
  const q = query(studentsCol, where("name", "==", name))
  const snapshot = await getDocs(q)

  if (snapshot.empty) {
    return null
  }

  return {
    id: snapshot.docs[0].id,
    ...snapshot.docs[0].data(),
  } as StudentData
}

// Fungsi untuk menyimpan data siswa (batch)
export async function saveStudents(students: StudentData[]) {
  try {
    // Hapus data lama
    const oldData = await getAllStudents()
    for (const student of oldData) {
      if (student.id) {
        await deleteDoc(doc(db, "students", student.id))
      }
    }

    // Masukkan data baru
    const studentsCol = collection(db, "students")
    for (const student of students) {
      await addDoc(studentsCol, {
        name: student.name,
        class: student.class,
        score: student.score,
        rewardMessage: student.rewardMessage,
      })
    }

    return true
  } catch (error) {
    console.error("Error saving students:", error)
    return false
  }
}
