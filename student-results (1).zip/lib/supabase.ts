import { createClient } from "@supabase/supabase-js"
import type { StudentData } from "@/components/student-results"

// Buat client Supabase dengan fallback ke localStorage jika environment variables tidak tersedia
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

// Cek apakah credentials tersedia
const isSupabaseConfigured = supabaseUrl && supabaseAnonKey

// Buat client hanya jika credentials tersedia
export const supabase = isSupabaseConfigured ? createClient(supabaseUrl, supabaseAnonKey) : null

// Fungsi untuk mengambil semua data siswa
export async function getAllStudents(): Promise<StudentData[]> {
  // Jika Supabase tidak dikonfigurasi, gunakan localStorage
  if (!supabase) {
    return getStudentsFromLocalStorage()
  }

  try {
    const { data, error } = await supabase.from("students").select("*")

    if (error) {
      console.error("Error fetching students from Supabase:", error)
      // Fallback ke localStorage jika ada error
      return getStudentsFromLocalStorage()
    }

    return data as StudentData[]
  } catch (error) {
    console.error("Exception when fetching students:", error)
    return getStudentsFromLocalStorage()
  }
}

// Fungsi untuk mencari siswa berdasarkan nama
export async function findStudentByName(name: string): Promise<StudentData | null> {
  // Jika Supabase tidak dikonfigurasi, gunakan localStorage
  if (!supabase) {
    return findStudentInLocalStorage(name)
  }

  try {
    const { data, error } = await supabase.from("students").select("*").ilike("name", name).limit(1).single()

    if (error) {
      console.error("Error finding student in Supabase:", error)
      // Fallback ke localStorage jika ada error
      return findStudentInLocalStorage(name)
    }

    return data as StudentData
  } catch (error) {
    console.error("Exception when finding student:", error)
    return findStudentInLocalStorage(name)
  }
}

// Fungsi untuk menyimpan data siswa (batch)
export async function saveStudents(students: StudentData[]): Promise<boolean> {
  // Selalu simpan ke localStorage sebagai backup
  saveStudentsToLocalStorage(students)

  // Jika Supabase tidak dikonfigurasi, hanya gunakan localStorage
  if (!supabase) {
    return true
  }

  try {
    // Hapus data lama
    const { error: deleteError } = await supabase.from("students").delete().not("id", "is", null)

    if (deleteError) {
      console.error("Error deleting old data from Supabase:", deleteError)
      return false
    }

    // Masukkan data baru
    const { error } = await supabase.from("students").insert(students)

    if (error) {
      console.error("Error saving students to Supabase:", error)
      return false
    }

    return true
  } catch (error) {
    console.error("Exception when saving students:", error)
    return false
  }
}

// Helper functions untuk localStorage

function getStudentsFromLocalStorage(): StudentData[] {
  if (typeof window === "undefined") return []

  try {
    const savedData = localStorage.getItem("studentData")
    if (savedData) {
      return JSON.parse(savedData) as StudentData[]
    }
  } catch (error) {
    console.error("Error parsing student data from localStorage:", error)
  }
  return []
}

function findStudentInLocalStorage(name: string): StudentData | null {
  if (typeof window === "undefined") return null

  try {
    const students = getStudentsFromLocalStorage()
    return students.find((student) => student.name.toLowerCase() === name.toLowerCase()) || null
  } catch (error) {
    console.error("Error finding student in localStorage:", error)
    return null
  }
}

function saveStudentsToLocalStorage(students: StudentData[]): void {
  if (typeof window === "undefined") return

  try {
    localStorage.setItem("studentData", JSON.stringify(students))
  } catch (error) {
    console.error("Error saving students to localStorage:", error)
  }
}
