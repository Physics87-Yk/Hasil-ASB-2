// This is a mock database of student information
// In a real application, this would be stored in a database

export const studentData = [
  // Kelas 1
  { name: "Ahmad Rizki", class: "1A", score: 85, rewardMessage: "Hebat! Teruslah belajar dengan semangat!" },
  { name: "Siti Nurhaliza", class: "1A", score: 92, rewardMessage: "Luar biasa! Kamu sangat berbakat!" },
  { name: "Budi Santoso", class: "1A", score: 78, rewardMessage: "Bagus! Pertahankan prestasimu!" },
  { name: "Dewi Kartika", class: "1A", score: 88, rewardMessage: "Sangat baik! Kamu telah bekerja keras!" },

  // Kelas 2
  { name: "Rini Susanti", class: "2A", score: 90, rewardMessage: "Sempurna! Kamu adalah bintang kelas!" },
  { name: "Andi Wijaya", class: "2A", score: 75, rewardMessage: "Baik! Teruslah berlatih!" },
  { name: "Putri Rahayu", class: "2A", score: 82, rewardMessage: "Bagus sekali! Kamu memiliki potensi besar!" },
  { name: "Dimas Pratama", class: "2A", score: 79, rewardMessage: "Bagus! Teruslah berusaha!" },

  // Kelas 3
  { name: "Rina Wati", class: "3A", score: 95, rewardMessage: "Luar biasa! Kamu sangat cerdas!" },
  { name: "Joko Widodo", class: "3A", score: 88, rewardMessage: "Sangat baik! Kamu telah berusaha keras!" },
  { name: "Anisa Rahma", class: "3A", score: 91, rewardMessage: "Hebat! Kamu memiliki pemahaman yang baik!" },
  { name: "Rizal Fahmi", class: "3A", score: 84, rewardMessage: "Bagus! Teruslah belajar dengan giat!" },

  // Kelas 4
  { name: "Maya Sari", class: "4A", score: 87, rewardMessage: "Sangat baik! Kamu telah menunjukkan kemajuan!" },
  { name: "Dodi Irawan", class: "4A", score: 79, rewardMessage: "Bagus! Teruslah berlatih!" },
  { name: "Lina Marlina", class: "4A", score: 93, rewardMessage: "Luar biasa! Kamu sangat berbakat!" },
  { name: "Agus Setiawan", class: "4A", score: 81, rewardMessage: "Bagus sekali! Pertahankan semangat belajarmu!" },

  // Kelas 5
  { name: "Nita Anggraini", class: "5A", score: 89, rewardMessage: "Sangat baik! Kamu telah bekerja keras!" },
  { name: "Rudi Hartono", class: "5A", score: 76, rewardMessage: "Baik! Teruslah berlatih!" },
  { name: "Sinta Dewi", class: "5A", score: 94, rewardMessage: "Luar biasa! Kamu sangat cerdas!" },
  { name: "Bima Sakti", class: "5A", score: 82, rewardMessage: "Bagus sekali! Kamu memiliki potensi besar!" },

  // Kelas 6
  { name: "Dina Maulida", class: "6A", score: 91, rewardMessage: "Hebat! Kamu memiliki pemahaman yang baik!" },
  { name: "Eko Prasetyo", class: "6A", score: 85, rewardMessage: "Bagus! Teruslah belajar dengan giat!" },
  { name: "Fani Wijaya", class: "6A", score: 88, rewardMessage: "Sangat baik! Kamu telah berusaha keras!" },
  { name: "Galih Ramadhan", class: "6A", score: 80, rewardMessage: "Bagus! Pertahankan prestasimu!" },

  // Kelas 7
  { name: "Hani Safitri", class: "7A", score: 93, rewardMessage: "Luar biasa! Kamu sangat berbakat!" },
  { name: "Irfan Hakim", class: "7A", score: 77, rewardMessage: "Baik! Teruslah berlatih!" },
  { name: "Jasmine Putri", class: "7A", score: 86, rewardMessage: "Sangat baik! Kamu telah menunjukkan kemajuan!" },
  { name: "Kiki Saputra", class: "7A", score: 82, rewardMessage: "Bagus sekali! Kamu memiliki potensi besar!" },

  // Kelas 8
  { name: "Laras Ayu", class: "8A", score: 90, rewardMessage: "Hebat! Teruslah belajar dengan semangat!" },
  { name: "Maman Suparman", class: "8A", score: 78, rewardMessage: "Bagus! Teruslah berusaha!" },
  { name: "Nadia Putri", class: "8A", score: 95, rewardMessage: "Luar biasa! Kamu sangat cerdas!" },
  { name: "Oki Gunawan", class: "8A", score: 83, rewardMessage: "Bagus sekali! Pertahankan semangat belajarmu!" },

  // Kelas 9
  { name: "Putri Indah", class: "9A", score: 92, rewardMessage: "Luar biasa! Kamu sangat berbakat!" },
  { name: "Qori Ramadhan", class: "9A", score: 84, rewardMessage: "Bagus! Teruslah belajar dengan giat!" },
  { name: "Ratna Sari", class: "9A", score: 89, rewardMessage: "Sangat baik! Kamu telah bekerja keras!" },
  { name: "Surya Darma", class: "9A", score: 81, rewardMessage: "Bagus sekali! Kamu memiliki potensi besar!" },
]
