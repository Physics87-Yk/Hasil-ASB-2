"use client"

import { useState, useEffect } from "react"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { getAllStudents, findStudentByName } from "@/lib/supabase"

// Define the student data type
export type StudentData = {
  id?: number | string
  name: string
  class: string
  score: number
  rewardMessage: string
}

export function StudentResults() {
  const [name, setName] = useState("")
  const [result, setResult] = useState<StudentData | null>(null)
  const [notFound, setNotFound] = useState(false)
  const [loading, setLoading] = useState(false)
  const [studentData, setStudentData] = useState<StudentData[]>([])
  const [dataLoaded, setDataLoaded] = useState(false)

  // Load student data on component mount
  useEffect(() => {
    async function loadData() {
      try {
        const data = await getAllStudents()
        setStudentData(data)
      } catch (error) {
        console.error("Error loading student data:", error)
      } finally {
        setDataLoaded(true)
      }
    }

    loadData()
  }, [])

  const handleSearch = async () => {
    if (!name.trim()) return

    setLoading(true)
    setNotFound(false)

    try {
      // Cari siswa berdasarkan nama
      const student = await findStudentByName(name)

      if (student) {
        setResult(student)
        setNotFound(false)
      } else {
        setResult(null)
        setNotFound(true)
      }
    } catch (error) {
      console.error("Error searching for student:", error)
      setNotFound(true)
    } finally {
      setLoading(false)
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600"
    if (score >= 75) return "text-blue-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <div className="space-y-6">
      <div className="flex gap-2">
        <Input
          placeholder="Masukkan nama lengkap"
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          className="flex-1"
          disabled={loading}
        />
        <Button onClick={handleSearch} type="submit" disabled={loading}>
          <Search className="h-4 w-4 mr-2" />
          {loading ? "Mencari..." : "Cari"}
        </Button>
      </div>

      {dataLoaded && studentData.length === 0 && (
        <Alert>
          <AlertTitle>Data belum tersedia</AlertTitle>
          <AlertDescription>Admin belum mengupload data siswa. Silakan hubungi guru Anda.</AlertDescription>
        </Alert>
      )}

      {notFound && (
        <Alert variant="destructive">
          <AlertTitle>Tidak ditemukan</AlertTitle>
          <AlertDescription>
            Maaf, nama yang Anda masukkan tidak ditemukan dalam database. Pastikan nama ditulis dengan benar.
          </AlertDescription>
        </Alert>
      )}

      {result && (
        <Card className="overflow-hidden">
          <CardHeader className="bg-primary/5">
            <CardTitle>{result.name}</CardTitle>
            <CardDescription>Kelas {result.class}</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-6xl font-bold mb-2 tracking-tight leading-none">
                <span className={getScoreColor(result.score)}>{result.score}</span>
              </div>
              <p className="text-sm text-muted-foreground">Nilai Ujian</p>
            </div>
          </CardContent>
          <CardFooter className="bg-primary/5 flex flex-col items-center p-6">
            <div className="text-center">
              <p className="font-medium text-lg mb-1">Pesan Reward</p>
              <p className="italic">&quot;{result.rewardMessage}&quot;</p>
            </div>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}
