"use client"

import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"
import { utils, write } from "xlsx"

export function ExcelTemplateDownload() {
  const downloadTemplate = () => {
    // Create a workbook with a worksheet
    const wb = utils.book_new()

    // Sample data
    const sampleData = [
      { name: "Ahmad Rizki", class: "1A", score: 85, rewardMessage: "Hebat! Teruslah belajar dengan semangat!" },
      { name: "Siti Nurhaliza", class: "1A", score: 92, rewardMessage: "Luar biasa! Kamu sangat berbakat!" },
      { name: "Budi Santoso", class: "1A", score: 78, rewardMessage: "Bagus! Pertahankan prestasimu!" },
    ]

    // Create a worksheet from the data
    const ws = utils.json_to_sheet(sampleData)

    // Add the worksheet to the workbook
    utils.book_append_sheet(wb, ws, "Data Siswa")

    // Generate Excel file as an array buffer
    const excelBuffer = write(wb, { bookType: "xlsx", type: "array" })

    // Convert to Blob
    const blob = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" })

    // Create download link
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "template-data-siswa.xlsx"
    document.body.appendChild(a)
    a.click()

    // Clean up
    setTimeout(() => {
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }, 0)
  }

  return (
    <Button variant="outline" onClick={downloadTemplate}>
      <Download className="mr-2 h-4 w-4" />
      Download Template Excel
    </Button>
  )
}
