import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Home } from "lucide-react"
import { ExcelTemplateDownload } from "@/lib/excel-template"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b p-4">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <h1 className="font-bold text-xl">Admin Panel Hasil Ujian</h1>
          <div className="flex gap-2">
            <ExcelTemplateDownload />
            <Button variant="outline" asChild>
              <Link href="/">
                <Home className="mr-2 h-4 w-4" />
                Halaman Utama
              </Link>
            </Button>
          </div>
        </div>
      </header>
      {children}
    </div>
  )
}
