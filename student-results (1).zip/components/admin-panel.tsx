"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Save, FileSpreadsheet, AlertCircle, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { read, utils } from "xlsx"
import type { StudentData } from "./student-results"
import { saveStudents, supabase } from "@/lib/supabase"

export function AdminPanel() {
  const [studentData, setStudentData] = useState<StudentData[]>([])
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [storageMode, setStorageMode] = useState<"supabase" | "localStorage">("localStorage")

  // Deteksi mode penyimpanan saat komponen dimuat
  useEffect(() => {
    setStorageMode(supabase ? "supabase" : "localStorage")
  }, [])

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null)
    setSuccess(null)

    const file = e.target.files?.[0]
    if (!file) return

    try {
      // Read the Excel file
      const data = await file.arrayBuffer()
      const workbook = read(data)

      // Get the first worksheet
      const worksheet = workbook.Sheets[workbook.SheetNames[0]]

      // Convert to JSON
      const jsonData = utils.sheet_to_json<any>(worksheet)

      // Validate and transform the data
      const transformedData: StudentData[] = jsonData.map((row, index) => {
        // Check if required fields exist
        if (!row.name || !row.class || row.score === undefined || !row.rewardMessage) {
          throw new Error(
            `Baris ${index + 2}: Data tidak lengkap. Pastikan kolom name, class, score, dan rewardMessage ada.`,
          )
        }

        // Validate score is a number
        const score = Number(row.score)
        if (isNaN(score)) {
          throw new Error(`Baris ${index + 2}: Nilai (score) harus berupa angka.`)
        }

        return {
          name: String(row.name),
          class: String(row.class),
          score: score,
          rewardMessage: String(row.rewardMessage),
        }
      })

      setStudentData(transformedData)
    } catch (err) {
      console.error("Error processing Excel file:", err)
      setError(err instanceof Error ? err.message : "Terjadi kesalahan saat memproses file Excel.")
    }

    // Reset the file input
    e.target.value = ""
  }

  const saveData = async () => {
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const result = await saveStudents(studentData)

      if (result) {
        setSuccess(`Data berhasil disimpan ke ${storageMode === "supabase" ? "database" : "penyimpanan lokal"}!`)
      } else {
        setError(`Gagal menyimpan data ke ${storageMode === "supabase" ? "database" : "penyimpanan lokal"}.`)
      }
    } catch (err) {
      console.error("Error saving data:", err)
      setError("Terjadi kesalahan saat menyimpan data.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {storageMode === "localStorage" && (
        <Alert>
          <Info className="h-4 w-4" />
          <AlertTitle>Mode Penyimpanan Lokal</AlertTitle>
          <AlertDescription>
            Aplikasi berjalan dalam mode penyimpanan lokal (localStorage). Data hanya tersimpan di browser ini. Untuk
            menggunakan database Supabase, tambahkan environment variables yang diperlukan.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Upload Data Siswa</CardTitle>
          <CardDescription>Upload file Excel dengan kolom: name, class, score, dan rewardMessage</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Button asChild variant="outline" className="w-full h-32 flex flex-col gap-2">
              <label>
                <input
                  type="file"
                  accept=".xlsx, .xls"
                  className="sr-only"
                  onChange={handleFileUpload}
                  disabled={loading}
                />
                <FileSpreadsheet className="h-8 w-8" />
                <span>Pilih File Excel</span>
                <span className="text-xs text-muted-foreground">(.xlsx atau .xls)</span>
              </label>
            </Button>
          </div>

          {error && (
            <Alert variant="destructive" className="mt-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mt-4 bg-green-50 border-green-200">
              <AlertTitle>Sukses</AlertTitle>
              <AlertDescription>{success}</AlertDescription>
            </Alert>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={saveData} disabled={studentData.length === 0 || loading} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            {loading
              ? "Menyimpan..."
              : `Simpan Data ke ${storageMode === "supabase" ? "Database" : "Penyimpanan Lokal"}`}
          </Button>
        </CardFooter>
      </Card>

      {studentData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Preview Data</CardTitle>
            <CardDescription>{studentData.length} data siswa telah diupload</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="border rounded-md max-h-96 overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>No</TableHead>
                    <TableHead>Nama</TableHead>
                    <TableHead>Kelas</TableHead>
                    <TableHead>Nilai</TableHead>
                    <TableHead>Pesan Reward</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {studentData.map((student, index) => (
                    <TableRow key={index}>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>{student.name}</TableCell>
                      <TableCell>{student.class}</TableCell>
                      <TableCell>{student.score}</TableCell>
                      <TableCell className="max-w-xs truncate">{student.rewardMessage}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
