import { StudentResults } from "@/components/student-results"

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-b from-blue-50 to-white">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">Hasil Ujian Bersama</h1>
          <p className="text-gray-600 mt-2">Masukkan nama Anda untuk melihat hasil ujian</p>
        </div>
        <StudentResults />
      </div>
    </main>
  )
}
