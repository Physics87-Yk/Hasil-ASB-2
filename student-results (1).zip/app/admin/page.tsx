import { AdminPanel } from "@/components/admin-panel"

export default function AdminPage() {
  return (
    <main className="min-h-screen p-6 bg-gray-50">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800">Admin Panel</h1>
          <p className="text-gray-600 mt-2">Upload data siswa dari file Excel</p>
        </div>
        <AdminPanel />
      </div>
    </main>
  )
}
